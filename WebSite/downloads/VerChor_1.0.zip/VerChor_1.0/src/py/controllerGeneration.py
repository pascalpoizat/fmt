#
#
# Name:   controllerGeneration.py - Classes for conversation protocols
# Author: Gwen Sala\"un.
# Date:   07-9-2010
# changes for projection
# Matthias Guedemann
# Start Date: 21-11-2011
##
################################################################################
 

from time import time

from subprocess import *
import os.path

 


# Labels in conversation protocols tuple
 
class Label:
    def __init__(self,sender,receiver,message):

        self._sender=sender
        self._receiver=receiver
        self._message=message.lower()

    def getSender(self):
        return self._sender

    def getMessage(self):
        return self._message

    def getReceiver(self):
        return self._receiver

    def printLabel(self):
        print " - (",
        self._sender.printPeer()
        print ",",
        self._receiver.printPeer()
        print ",",
        print self._message,
        print ") -> ",

##
# State class
class State:

    def __init__(self,name, interleaving = False):
        self._name=name
        self.interleavingFlag = interleaving

    def getName(self):
        return self._name

    def printState(self):
        print self._name,

    # will signal whether the state is part of a full interleaving
    def getInterleavingFlag(self):
        return self.interleavingFlag

    def setInterleavingFlag(self, flag):
        self.interleavingFlag = flag

##
# Peer class
class Peer:
    def __init__(self,name):
        self._name=name.lower()

    def getName(self):
        return self._name

    def printPeer(self):
        print self._name,

##
# Transition class -> source peer + label + target peer.
class Transition:
    def __init__(self,src,label,tgt):
        self._src=src
        self._tgt=tgt
        self._label=label

    ##
    # Returns the transition's source peer.
    # @return source peer name.
    # @defreturn String.
    def getSource(self):
        return self._src

    ##
    # Returns the transition's target peer.
    # @return target peer name.
    # @defreturn String.
    def getTarget(self):
        return self._tgt

    ##
    # Returns the transition's label.
    # @return transition label name.
    # @defreturn String.
    def getLabel(self):
        return self._label

    ##
    # Sets the transition's label.
    # @return transition label name.
    # @defreturn String.
    def setLabel(self,label):
        self._label=label

    def printTransition(self):
        self._src.printState()
        self._tgt.printState()
        self._label.printLabel()


# synchronization transition for monitors
# these are treated specially
 
class SyncTransition(Transition):

    def __init__ (self, src, label, tgt, original):
        Transition.__init__(self, src, Label(label.getSender(), label.getReceiver(), "synchro"), tgt)

        self.liste = []
        self.addSyncTrans(original, label)
        self.originalMessage = original

    def getOriginal(self):
        return self.originalMessage

    def getLabelSet(self):
        return map(lambda(orig, label): label, self.liste)

    def getTupelSet(self):
        return self.liste

    # will generate the necessary parallel composition of sync messages
    def generateSyncs(self, f, withInit = False, pid = False):

        if not pid:
            relevantLabels = self.getLabelSet()
        else:
            relevantLabels = filter(lambda label: label.getSender().getName() == pid, self.getLabelSet())
        i = len(relevantLabels)

        if i > 1:
            f.write("  par\n")
        for j in range(0, i):
            label = relevantLabels[j]
            if withInit:
                f.write("init_")
            f.write(label.getSender().getName() + "_" +
                    label.getReceiver().getName() + "_" +
                    label.getMessage() + "\n")
            if (j + 1 < i):
                f.write(" ||\n")

        if i > 1:
            f.write ("  end par;\n")
        else:
            f.write(";\n")

    def printTransition(self):
        self._src.printState()
        self._tgt.printState()
        i = len(self.getLabelSet())
        print "- (\n",
        for j in range(0,i):
            print "  ",
            (orig, label) = self.getTupelSet()[j]
            print label.getSender().getName() + " -> sync" + orig, " -> ", label.getReceiver().getName(),
            if j + 1 < i:
                print "\n",
        print "\n) ->",

    def addSyncTrans(self, original, label):
        self.liste.append((original, label))

##
# Conversation protocol class.
class CP:
    def __init__(self,name,init):
        self._name = name
        self._s0 = init
        self._S = []
        self._T = []

    def getName (self):
        return self._name

    def getInitialState(self):
        return self._s0

    def setInitialState (self, initialState):
        self._s0 = initialState

    def addState(self, state):
        if not state.getName() in map(lambda s: s.getName(), self._S):
            self._S.append(state)

    def addTransition(self,transition):
        self._T.append(transition)

    def removeTransition (self, transition):
        self._T.remove (transition)

    # checks whether there is a non-deterministic choice
    # between senders, i.e. a state where two different peers
    # want to send
    def checkNonDeterministicSenderChoice(self):
        for state in self._S:
            outgoingTransitions = filter (lambda trans: trans.getSource().getName() == state.getName(), self._T)
            senderPeers = set (map (lambda trans: trans.getLabel().getSender(), outgoingTransitions))
            if len (senderPeers) > 1:
                print "Error in Choreography", self._name, "! The state ", state.getName(), "has multiple sending peers"
                return False
        return True

    def checkAllConditions(self):
        return self.checkNonDeterministicSenderChoice()

    # return all the predecessors of the given state
    def getPredecessors(self, state):
        transToMe = filter (lambda trans: state.getName() == trans.getTarget().getName(), self._T)

        predecessors = []
        for predecessor in map (lambda trans: trans.getSource(), transToMe):
            if predecessor not in predecessors:
                predecessors.append (predecessor)

        return predecessors

    # creates new transition in the choreography
    # source and target must exist
    def createLabel (self, sourceName, targetName, label):

        peers = self.getPeers()

        names = map (lambda x: x._name, peers)
        if sourceName not in names or targetName not in names:
            print "source or target peer does not exist"
        else:
            return (Label (filter (lambda x: x.getName() == sourceName, peers)[0],
                           filter (lambda x: x.getName() == targetName, peers)[0],
                           label))

    #
    # returns a list of transitions with
    # the same label as offendingLabel
    # (these are the potential transtions that have to be synchronized)
    #
    def findOffendingTransitions (self, offendingLabel):
        return (filter (lambda trans:
                        trans.getLabel().getSender()._name == offendingLabel.getSender()._name and
                        trans.getLabel().getReceiver()._name == offendingLabel.getReceiver()._name and
                        trans.getLabel().getMessage () == offendingLabel.getMessage(),
                        self._T))

    # inserts a synchronization label for the offending transition
    #
    def insertSynchroMessage (self, offendingTransition):

        synchroState = offendingTransition.getSource()
        offendingPeer = offendingTransition.getLabel().getSender()

        print "synchronization state is ", synchroState.getName(), " offending peer is ", offendingPeer.getName()

        synchroState.printState()

        newState = State (synchroState.getName() + "_prime")
        stateNr = 0

        self.addState(newState)


        if synchroState.getName() == self.getInitialState().getName():
            print "synchronization state is also initial state!\nThe new state will be set as initial"
            self.setInitialState(newState)

        newTrans = []
        changedTrans = []

        addedSyncTrans = False 

        # get all transitions entering the synchronization state where:
        # - the offending peer is not the sender and
        # - the offending peer is not the receiver
        targetTrans = filter (lambda trans:
                                trans.getTarget ().getName() == synchroState.getName() and
                                trans.getLabel().getSender().getName() != offendingPeer.getName() and
                                trans.getLabel().getReceiver().getName() != offendingPeer.getName() and
                                not isinstance(trans, SyncTransition),
                                self.getAllTransitions())

        # select from targetTrans all transitions with unique workflow
        singleWorkFlowTrans = filter(lambda trans:
                                         not (trans.getTarget().getInterleavingFlag() and
                                              trans.getSource().getInterleavingFlag()),
                                         targetTrans)

        # select from targetTrans all transitions which are part of an interleaving
        multipleWorkFlowTrans = filter(lambda trans:
                                           trans.getTarget().getInterleavingFlag() and
                                           trans.getSource().getInterleavingFlag(),
                                           targetTrans)

        # get all synchronization transitions to the synchroniztion state
        syncTransToExtend = filter(lambda trans:
                                    isinstance(trans, SyncTransition) and
                                    trans.getTarget().getName() == synchroState.getName(),
                                    self.getAllTransitions())

        print "incoming to synchro state: ", map (lambda trans: trans.printTransition (), targetTrans)
        print "incoming syncs: ", map (lambda trans: trans.printTransition (), syncTransToExtend)

        # save old transitions to synchro state to change later
        # but: do not touch the sync transitions!
        old_trans = self.getTransitions(synchroState.getName())


        # this will create a single new state and
        # a synchronization transition with potentially multiple senders
        for trans in multipleWorkFlowTrans:
            newLabel = Label (trans.getLabel().getSender(),
                                offendingPeer,
                                "sync" + trans.getSource().getName()+trans.getTarget().getName()+
                                offendingTransition.getLabel().getMessage())
            labels = map (lambda trans: trans.getLabel(), newTrans)
            labelNames = map (lambda label: label.getSender().getName() + "_" + label.getReceiver().getName() + "_" + label.getMessage(), labels)
            print labelNames
            if not newLabel.getSender().getName() + "_" + newLabel.getReceiver().getName() + "_" + newLabel.getMessage() in labelNames:
                specificSyncTrans = filter(lambda t: t.getSource().getName() == synchroState.getName() and
                                            t.getTarget().getName() == newState.getName(),
                                            newTrans)
                if reduce (lambda flagged, x: flagged or x,
                           map(lambda trans: trans.getTarget().getInterleavingFlag(), old_trans), False):
                    newState.setInterleavingFlag(True)
                if len(specificSyncTrans) > 0:
                    print "adding new sync possibility to existing trans"
                    if len(specificSyncTrans) > 1:
                        print "very strange ... should be inspected!"
                    specificSyncTrans[0].addSyncTrans(offendingTransition.getLabel().getMessage(), newLabel)
                else:
                    newTrans.append(SyncTransition (synchroState, newLabel, newState, offendingTransition.getLabel().getMessage()))
                changedTrans.append (trans)
            else:
                print "not adding label twice"

        #adjust all transitions from synchroState where offending peer is not the sender
        oldTrans = filter(lambda t: 
                          t.getLabel().getSender().getName() != offendingPeer.getName()
                          and t.getSource().getName() == synchroState.getName(),
                          self._T)

        # this will create multiple new states and
        # synchronization transitions with single sender
        for trans in singleWorkFlowTrans:

            newLabel = Label (trans.getLabel().getSender(),
                                offendingPeer,
                                "sync" + trans.getSource().getName()+trans.getTarget().getName()+
                                offendingTransition.getLabel().getMessage())
            labels = map (lambda trans: trans.getLabel(), newTrans)
            labelNames = map (lambda label: label.getSender().getName() + "_" + label.getReceiver().getName() + "_" + label.getMessage(), labels)
            print labelNames
            if not newLabel.getSender().getName() + "_" + newLabel.getReceiver().getName() + "_" + newLabel.getMessage() in labelNames:
                newState = State (synchroState.getName() + "_prime_" + str(stateNr))
                stateNr = stateNr + 1
                self.addState(newState)

                newTrans.append(SyncTransition (newState, newLabel, synchroState, offendingTransition.getLabel().getMessage()))
                self.removeTransition(trans)

                adjustedTrans = Transition(trans.getSource(), trans.getLabel(), newState)
                self.addTransition(adjustedTrans)
                changedTrans.append (adjustedTrans)

            else:
                print "not adding label twice"

        # add new sync possibilities to existing sync transitions
        for trans in syncTransToExtend:
            offendingMessage = offendingTransition.getLabel().getMessage()
            senderSet = set(map(lambda l: l.getSender(), trans.getLabelSet()))
            for sender in senderSet:
                newLabel = Label (sender, 
                                    offendingPeer,
                                    "sync" + trans.getSource().getName()+trans.getTarget().getName()+
                                    offendingMessage)
                trans.addSyncTrans(offendingMessage, newLabel)
                addedSyncTrans = True

        # either we add sync trans to existing ones
        # or we introduce new sync transitions and new states!
        if len(multipleWorkFlowTrans) > 0:
            for trans in old_trans:
                self.removeTransition (trans)
                targetState = trans.getTarget()
                if trans.getTarget().getName() == synchroState.getName():
                    print "\nself-loop at synchronization state -> using new State ", newState.getName(), " instead"
                    targetState = newState
                newTrans.append (Transition (newState,
                                             trans.getLabel(),
                                             targetState))

        # if any of the new labels was present as synchronization in the old choreo,
        # then we are in a (currently) non-fixable loop -> stop choreo extension
        filterFunc = (lambda label:
                      label.getSender().getName() + "_" + label.getReceiver().getName() + "_" + label.getMessage())
        newlabels = map (filterFunc, map (lambda trans: trans.getLabel(), newTrans))
        oldlabels = map (filterFunc, map (lambda trans: trans.getLabel(), self._T))

        if False: 
            print "old labels: ", oldlabels
            print "new labels: ", newlabels
            print "we are entering cyclic behavior here, this choreo is currently not fixable\n"
            return False
        elif len (changedTrans) == 0 and not addedSyncTrans:
            print "no fixable transition was found -> cannot fix choreography"
            return False
        else:
            map (lambda trans: self.addTransition(trans), newTrans)
            return True


    def printCP(self):
        print "-------"
        print self._name+" ( init:",
        self._s0.printState()
        print ")"
        for t in self._T:
            print "(",
            t.printTransition()
            print ")"
        print "-------"

    # Builds CP alphabet without a peer
    def buildAlphabetExcludingPeer(self,pid, skipSyncs):
        alpha=[]
        for t in self._T:
            # if skipSyncs does not hold, then all sync Transitions will
            # be generated in the alphabet!
            # the idea is that these are not part of the alphabet of the
            # peer, and therefore must be hidden in the aux peer

            if not isinstance(t, SyncTransition):
                sender= t.getLabel().getSender().getName()
                receiver= t.getLabel().getReceiver().getName()
                if (not(pid==sender) and not(pid==receiver)):
                    res=sender+"_"+receiver+"_"+t.getLabel().getMessage()
                    if not(res in alpha):
                        alpha.append(res)
            elif (not skipSyncs and isinstance (t, SyncTransition)):
                resultList = t.getLabelSet()
                for l in resultList:
                    res = l.getSender().getName() + "_" + l.getReceiver().getName()+"_" + l.getMessage()
                    if not(res in alpha):
                        alpha.append(res)
        return alpha

    # Builds CP alphabet for a precise peer
    def buildAlphabetIncludingPeer(self,pid, skipSyncs = True):
        alpha=[]
        for t in self._T:
            if isinstance (t, SyncTransition) and skipSyncs:
                continue
            if isinstance(t, SyncTransition):
                resultList = t.getLabelSet()
                for l in resultList:
                    if pid == l.getSender().getName() or pid == l.getReceiver().getName():
                        res = l.getSender().getName() + "_" + l.getReceiver().getName()+"_" + l.getMessage()
                        if not(res in alpha):
                            alpha.append(res)
            else:
                sender=t.getLabel().getSender().getName()
                receiver=t.getLabel().getReceiver().getName()
                if (pid==sender) or (pid==receiver):
                    res=sender+"_"+receiver+"_"+t.getLabel().getMessage()
                    if not(res in alpha):
                        alpha.append(res)
        return alpha

    # Builds CP alphabet for a precise peer (only when pid is the receiver)
    def buildAlphabetIncludingPeerREC(self,pid, skipSyncs = True):
        alpha=[]
        for t in self._T:
            if isinstance (t, SyncTransition) and skipSyncs:
                continue
            if isinstance(t, SyncTransition):
                resultList = t.getLabelSet()
                if pid in map(lambda l: l.getReceiver().getName(), resultList):
                    for l in resultList:
                        res = sender + "_" + receiver+"_" + l.getMessage()
                        if not(res in alpha):
                            alpha.append(res)
            else:
                sender=t.getLabel().getSender().getName()
                receiver=t.getLabel().getReceiver().getName()
                if (pid==receiver):
                    res=sender+"_"+receiver+"_"+t.getLabel().getMessage()
                    if not(res in alpha):
                        alpha.append(res)
        return alpha

    # Builds CP alphabet for a precise peer + keeps directions (!/?)
    def buildAlphabetIncludingPeerDir(self,pid):
        alpha=[]
        for t in self._T:
            if isinstance (t, SyncTransition):
                continue
            sender=t.getLabel().getSender().getName()
            receiver=t.getLabel().getReceiver().getName()
            if (pid==sender):
                res=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_EM"
                if not(res in alpha):
                    alpha.append(res)
            if (pid==receiver):
                res=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_REC"
                if not(res in alpha):
                    alpha.append(res)
        return alpha

    # Builds alphabet for a precise peer: keeps only receptions (with direction)
    #  and choice actions
    def buildAlphabetChoiceRec(self,pid):
        alpha=[]
        for t in self._T:
            sender=t.getLabel().getSender().getName()
            receiver=t.getLabel().getReceiver().getName()
            if (pid==receiver):
               res=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_REC"
               if not(res in alpha):
                  alpha.append(res)
        return alpha

    # Builds alphabet for a precise peer: keeps only emissions (with direction)
    def buildAlphabetEm(self,pid):
        alpha=[]
        for t in self._T:
            if isinstance (t, SyncTransition):
                continue
            sender=t.getLabel().getSender().getName()
            receiver=t.getLabel().getReceiver().getName()
            if (pid==sender):
               res=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_EM"
               if not(res in alpha):
                  alpha.append(res)
        return alpha


    # Builds peer alphabet for a precise peer + keeps receptions
    def buildAlphabetIncludingPeer_PQ(self,pid, skipSyncs = True):
        alpha=[]
        for t in self._T:
            if isinstance (t, SyncTransition) and skipSyncs:
                continue
            if isinstance(t, SyncTransition):
                resultList = t.getLabelSet()
                if pid == t.getLabel().getSender().getName() or pid in map(lambda l: l.getReceiver().getName(), resultList):
                    for l in resultList:
                        res = sender + "_" + receiver+"_" + l.getMessage()
                        if not(res in alpha):
                            alpha.append(res)
            else:
                sender=t.getLabel().getSender().getName()
                receiver=t.getLabel().getReceiver().getName()
                if (pid==sender):
                    res=sender+"_"+receiver+"_"+t.getLabel().getMessage()
                    if not(res in alpha):
                        alpha.append(res)
                if (pid==receiver):
                    res=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_REC"
                    if not(res in alpha):
                        alpha.append(res)
        return alpha

    # Builds peer alphabet for a precise peer + keeps receptions
    def buildAlphabetIncludingPeer_PQbis(self,pid, skipSyncs = True):
        alpha=[]
        for t in self._T:
            sender=t.getLabel().getSender().getName()
            receiver=t.getLabel().getReceiver().getName()
            if isinstance (t, SyncTransition) and skipSyncs:
                continue
            elif isinstance (t, SyncTransition):
                resultList = t.getLabelSet()
                if pid in map(lambda l: l.getSender().getName(), t.getLabelSet()) or pid in map(lambda l: l.getReceiver().getName(), resultList):
                    for l in resultList:
                        sender = l.getSender().getName()
                        receiver = l.getReceiver().getName()
                        if pid == sender or pid == receiver:
                            res = sender + "_" + receiver+"_" + l.getMessage()
                            if not(res in alpha):
                                alpha.append(res)
            else:
                if (pid==sender):
                    res=sender+"_"+receiver+"_"+t.getLabel().getMessage()
                    if not(res in alpha):
                        alpha.append(res)
                if (pid==receiver):
                    res=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_REC"
                    res2=sender+"_"+receiver+"_"+t.getLabel().getMessage()
                    if not(res in alpha):
                        alpha.append(res)
                    if not(res2 in alpha):
                        alpha.append(res2)
        return alpha

    def buildAlphabetMonitor(self, pid, renameEmit = False, includeSyncInits = True):

        syncTransitions = filter (lambda trans:
                                  isinstance (trans, SyncTransition) and
                                  len (filter (lambda label: pid == label.getSender().getName() or
                                       pid == label.getReceiver().getName (),
                                       trans.getLabelSet())) > 0,
                                   self._T)

        sendTransitions = filter (lambda trans:
                                  pid == trans.getLabel().getSender().getName() and
                                  not isinstance (trans, SyncTransition),
                                  self._T)

        syncTransForPeer = filter (lambda trans:
                                   isinstance (trans, SyncTransition) and
                                   len(filter(lambda label: pid == label.getSender().getName(), trans.getLabelSet())) > 0,
                                   self._T)

        alpha=[]
        for t in syncTransitions:
            # first check if the transition is a synchronization transition
            
            resultList = t.getLabelSet()
            for l in resultList:
                sender = l.getSender().getName()
                receiver = l.getReceiver().getName()
                if pid == sender or pid == receiver:
                    res = sender + "_" + receiver+"_" + l.getMessage()
                    if not(res in alpha):
                        alpha.append(res)
            

        for t in sendTransitions:
            sender = t.getLabel().getSender().getName()
            receiver = t.getLabel().getReceiver().getName()

            # split send message a one peer into a reception a emission to be in the monitor
            res1=sender+"_"+receiver+"_"+t.getLabel().getMessage()
            if not(res1 in alpha):
                alpha.append(res1)

            if renameEmit:
                res2=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_EM"
            else:
                res2=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_DLY"
            if not(res2 in alpha):
                alpha.append(res2)

        if includeSyncInits:
            for t in syncTransForPeer:
                for label in t.getLabelSet():
                    sender = label.getSender().getName()
                    if sender == pid:
                        receiver = label.getReceiver().getName()
                        res1 = "init_" + sender+"_"+receiver+"_"+label.getMessage()
                        if not(res1 in alpha):
                            alpha.append(res1)

        return alpha

    # builds alphabet for monitored peer a.k.a monitor || peer
    def buildAlphabetMonitored(self, pid, renameEmit = False, renameReceive = False):

        syncTransitions = filter (lambda trans:
                                  isinstance (trans, SyncTransition) and
                                  len (filter (lambda label: pid == label.getSender().getName() or
                                       pid == label.getReceiver().getName (),
                                       trans.getLabelSet())) > 0,
                                   self._T)

        sendTransitions = filter (lambda trans:
                                  pid == trans.getLabel().getSender().getName() and
                                  not isinstance (trans, SyncTransition),
                                  self._T)

        receiveTransitions = filter (lambda trans:
                                     pid == trans.getLabel().getReceiver().getName() and
                                     not isinstance (trans, SyncTransition),
                                     self._T)

        alpha = []
        for t in syncTransitions:
           
            resultList = t.getLabelSet()
            for l in resultList:
                sender = l.getSender().getName()
                receiver = l.getReceiver().getName()
                if pid == sender or pid == receiver:
                    res = sender + "_" + receiver+"_" + l.getMessage()
                    if not(res in alpha):
                        alpha.append(res)
            

        for t in sendTransitions:
            sender = t.getLabel().getSender().getName()
            receiver = t.getLabel().getReceiver().getName()

            # split send message a one peer into a reception a emission to be in the monitor
            res1=sender+"_"+receiver+"_"+t.getLabel().getMessage()
            if not(res1 in alpha):
                alpha.append(res1)

        for t in receiveTransitions:
            sender = t.getLabel().getSender().getName()
            receiver = t.getLabel().getReceiver().getName()

            # split send message a one peer into a reception a emission to be in the monitor
            res1=sender+"_"+receiver+"_"+t.getLabel().getMessage()
            if renameReceive:
                res1 = res1 + "_REC"
            if not(res1 in alpha):
                alpha.append(res1)

        return sorted (alpha)

    # alphabet for all synchronization process
    # onlyInits trigger the creation of only "init_" messages
    #    this is important for the parallel composition of the syncP processes
    def buildAlphabetSyncProcesses(self, pid, onlyInits = False):
        syncTransForPeer = filter (lambda trans:
                                   isinstance (trans, SyncTransition) and
                                   pid in map(lambda l: l.getSender().getName(), trans.getLabelSet()),
                                   self._T)
        messages = []
        for trans in syncTransForPeer:
            for label in trans.getLabelSet():
                if label.getSender().getName() == pid:
                    messages.append(pid + "_" + label.getReceiver().getName() + "_" + label.getMessage())
         

        initMessages = map (lambda msg: "init_" + msg, messages)

        if onlyInits:
            return initMessages
        else:
            return messages + initMessages


    # build synchronization alphabet for peer / monitor
    def buildSynchroSetPeerMonitor(self, pid):

        alpha = []

        sendTransitions = filter (lambda trans:
                                  pid == trans.getLabel().getSender().getName() and
                                  not isinstance (trans, SyncTransition),
                                  self._T)
        # synchronization is done over the messages emitted from the peer
        # these are received and cached by the monitor
        for t in sendTransitions:
            sender = t.getLabel().getSender().getName()
            receiver = t.getLabel().getReceiver().getName()

            res2=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_EM"
            if not(res2 in alpha):
                alpha.append(res2)

        return alpha

    def buildHideSetPeerMonitor(self, pid):
        return self.buildSynchroSetPeerMonitor(pid)

    # Builds alphabet for the couple (peer,queue)
    def buildAlphabetPeerQueue(self,pid):
        alpha=[]
        for t in self._T:
            sender=t.getLabel().getSender().getName()
            receiver=t.getLabel().getReceiver().getName()
            if (pid==sender):
               res=sender+"_"+receiver+"_"+t.getLabel().getMessage()
               if not(res in alpha):
                  alpha.append(res)
            if (pid==receiver):
               res1=sender+"_"+receiver+"_"+t.getLabel().getMessage()
               res2=sender+"_"+receiver+"_"+t.getLabel().getMessage()+"_REC"
               if not(res1 in alpha):
                  alpha.append(res1)
               if not(res2 in alpha):
                  alpha.append(res2)
        return alpha

    # Builds alphabet
    def buildAlphabet(self, skipSyncs = True):
        alpha=[]
        for t in self._T:
            if skipSyncs and isinstance (t, SyncTransition):
                continue
            elif isinstance (t, SyncTransition):
                resultList = t.getLabelSet()
                for l in resultList:
                    sender = l.getSender().getName()
                    receiver = l.getReceiver().getName()
                    res = sender + "_" + receiver+"_" + l.getMessage()
                    if not(res in alpha):
                        alpha.append(res)
            else:
                res=t.getLabel().getSender().getName()+"_"+t.getLabel().getReceiver().getName()+"_"+t.getLabel().getMessage()
                if not(res in alpha):
                    alpha.append(res)
        return alpha

    # Dumps alphabet
    def dumpAlphabet(self,alpha,f,any):
        l=0
        alpha = sorted (alpha)
        max=len(alpha)
        for e in alpha:
            f.write(e)
            if any:
               f.write(":any")
            l=l+1
            if l<max:
               f.write(",")

    # gets the set of synchronisation messages corresponding to one peer
    

    def dumpSyncMsgs(self, pid,f,any):
        l=0
        alpha = sorted (alpha)
        max = len(self.getSyncMsgsByPeer(pid))
       
        for e in alpha:
            f.write(e)
            if any:
               f.write(":any")
            l=l+1
            if l<max:
               f.write(",")


    # Dumps alphabet with REC suffixing each message
    def dumpAlphabetWithREC(self,alpha,f,any):
        l=0
        max=len(alpha)
        alpha = sorted (alpha)
        for e in alpha:
            f.write(e)
            f.write("_REC")
            if any:
               f.write(":any")
            l=l+1
            if l<max:
               f.write(",")

    # Dumps alphabet with EM suffixing each message
    def dumpAlphabetWithEM(self,alpha,f,any):
        l=0
        max=len(alpha)
        alpha = sorted (alpha)
        for e in alpha:
            f.write(e)
            f.write("_EM")
            if any:
               f.write(":any")
            l=l+1
            if l<max:
               f.write(",")

    # returns the list of transitions with tid as target
    def getTransitionsTarget (self, state):
        return (filter (lambda trans: trans.getTarget ().getName() == state.getName(), self._T))

    # Returns the list of transitions with sid as source
    def getTransitions(self,sid):
        subT=[]
        for t in self._T:
            if (sid==t.getSource().getName()):
               subT.append(t)
        return subT

    def getAllTransitions(self):
        return self._T

    # returns the peer with the given name
    def getPeerFromName(self, pid):
        peers = filter (lambda peer: peer.getName() == pid, self.getPeers())
        if len (peers) > 0:
            return peers[0]
        else:
            print "Error! peer ", pid, " not found in choreo!"
            return []

    # Returns the list of peers used in the CP
    def getPeers(self):
        peers=[]
        for t in self._T:
            sender=t.getLabel().getSender()
            receiver=t.getLabel().getReceiver()
            if not(sender in peers):
               peers.append(sender)
            if not(receiver in peers):
               peers.append(receiver)
        return peers

    # Generates an LNT module for a CP
    def cp2lnt(self, generateMonitors = False, fileName = False):
        name=self._name
        if not fileName:
            filename=name+".lnt"
        else:
            filename = fileName
        f=open(filename, 'w')
        f.write("module "+self._name+" with \"get\" is \n\n")
        alpha=self.buildAlphabet(False)
        self.generateDatatypes(alpha,f)
        f.write("process MAIN [")
        self.dumpAlphabet(alpha,f,True)
        f.write("] is \n")
        f.write("  p_"+self._s0.getName() +"[")
        self.dumpAlphabet(alpha,f,False)
        f.write("]\n")
        f.write("end process \n\n")
        for k in self._S:
           self.state2lnt(k.getName(),alpha,f)
        peers=self.getPeers()
        for p in peers:
           self.generatePeer(p.getName(),alpha,f)


       
        # adds the alphabet while generating a LNT process for the monitor
        if generateMonitors:
            for p in peers:
                self.generateMonitor (p, f)
                self.generateSyncProcesses(p,f)
                self.generateMonitoredPeers(p,f)
        for p in peers:
           self.generateQueue(p.getName(),alpha,f)
        for p in peers:
            self.generatePeerQueue(p.getName(),alpha,f, generateMonitors)
         

        f.write("end module \n")
        f.close()

    # Generates a few types (string, fifo) and functions
    def generateDatatypes(self,alpha,f):
        f.write("type Message is \n")
        self.dumpAlphabet(alpha,f,False)
        f.write("\n")
        f.write("with \"==\", \"!=\"\n")
        f.write("end type \n\n")
        f.write("type Queue is list of Message \n")
        f.write("with \"==\", \"!=\"\n")
        f.write("end type \n\n")
        f.write("type BoundedQueue is bqueue (queue: Queue, bound: Nat) \n")
        f.write("with \"==\", \"!=\"\n")
        f.write("end type \n\n")
        f.write("function insert (m: Message, q: Queue): Queue is \n")
        f.write("         case q in \n")
        f.write("         var hd: Message, tl: Queue in \n")
        f.write("             nil         -> return cons(m,nil) \n")
        f.write("           | cons(hd,tl) -> return insert(m,tl) \n")
        f.write("         end case \n")
        f.write("end function \n\n")
        f.write("function ishead (m: Message, q: Queue): Bool is \n")
        f.write("         case q in \n")
        f.write("         var hd: Message, tl: Queue in \n")
        f.write("             nil         -> return false \n")
        f.write("           | cons(hd,tl) -> return (m==hd) \n")
        f.write("         end case \n")
        f.write("end function \n\n")
        f.write("function remove (q: Queue): Queue is \n")
        f.write("         case q in \n")
        f.write("         var hd: Message, tl: Queue in \n")
        f.write("             nil         -> return nil \n")
        f.write("           | cons(hd,tl) -> return tl \n")
        f.write("         end case \n")
        f.write("end function \n\n")
        f.write("function count (q: Queue): Nat is \n")
        f.write("         case q in \n")
        f.write("         var hd: Message, tl: Queue in \n")
        f.write("             nil         -> return 0 \n")
        f.write("           | cons(hd,tl) -> return (1+count(tl)) \n")
        f.write("         end case \n")
        f.write("end function \n\n")
        f.write("function bisfull (bq: BoundedQueue): Bool is \n")
        f.write("  return ((count(bq.queue))==bq.bound) \n")
        f.write("end function \n\n")
        f.write("function binsert (m: Message, bq: BoundedQueue): BoundedQueue is \n")
        f.write("  if bisfull(bq) then  \n")
        f.write("     return bq  \n")
        f.write("  else  \n")
        f.write("     return bqueue(insert(m,bq.queue),bq.bound)  \n")
        f.write("  end if \n")
        f.write("end function \n\n")
        f.write("function bishead (m: Message, bq: BoundedQueue): Bool is \n")
        f.write("  return ishead(m,bq.queue) \n")
        f.write("end function \n\n")
        f.write("function bremove (bq: BoundedQueue): BoundedQueue is \n")
        f.write("  return bqueue(remove(bq.queue),bq.bound) \n")
        f.write("end function \n\n")
        f.write("function bcount (bq: BoundedQueue): Nat is \n")
        f.write("  return count(bq.queue) \n")
        f.write("end function \n\n")

    # Generates an LNT process for a state in the CP
    def state2lnt(self,sid,alpha,f):
        f.write("process p_"+sid+" [")
        self.dumpAlphabet(alpha,f,True)
        f.write("] is \n")
        subT=self.getTransitions(sid)
        max=len(subT)
        if (max>0):
          f.write(" select \n")
          i=0
          for t in subT:
              if isinstance(t, SyncTransition):
                  t.generateSyncs(f)
              else:
                  res=t.getLabel().getSender().getName()+"_"+t.getLabel().getReceiver().getName()+"_"+t.getLabel().getMessage()
                  f.write("  "+res+";")
              f.write(" p_"+t.getTarget().getName() +"[")
              self.dumpAlphabet(alpha,f,False)
              f.write("]\n")
              i=i+1
              if i<max:
                 f.write("\n[]\n")
          f.write(" end select \n")
        else:
          f.write(" null \n")
        f.write("end process \n\n")

    # Generates an LNT process for each peer
    def generatePeer(self,pid,alpha,f):
        exalphapid=self.buildAlphabetExcludingPeer(pid, False)
        incalphapid=self.buildAlphabetIncludingPeer(pid)
        incalphapid_dir=self.buildAlphabetIncludingPeerDir(pid)
        f.write("process peer_"+pid+" [")
        self.dumpAlphabet(incalphapid_dir,f,True)
        f.write("] is \n")
        f.write("  peer_"+pid+"_aux [")
        self.dumpAlphabet(incalphapid_dir,f,False)
        f.write("]\n")
        f.write("end process \n")
        f.write("process peer_"+pid+"_aux [")
        self.dumpAlphabet(incalphapid,f,True)
        f.write("] is \n")
        if (exalphapid!=[]):
           f.write(" hide ")
           self.dumpAlphabet(exalphapid,f,True)
           f.write(" in \n")
        f.write("   p_"+self._s0.getName() +" [")
        self.dumpAlphabet(alpha,f,False)
        f.write("]\n")
        if (exalphapid!=[]):
           f.write(" end hide \n")
        f.write("end process \n\n")

    ##
    # Generates the gate list for a peer queue process
    def generateAlphaQueue(self,alpha,f,any):
            max=len(alpha)
            i=0
            if alpha!=[]:
               f.write(" [")
               for m in alpha:
                   f.write(m)
                   if any:
                      f.write(":any")
                   f.write(",")
                   f.write(m+"_REC")
                   if any:
                      f.write(":any")
                   i=i+1
                   if i<max:
                      f.write(",")
               f.write("] ")

    ##
    # Generates an LNT process for a peer queue
    def generateQueue(self,pid,alpha,f):

            f.write("process ")
            pname="queue_"+pid
            f.write(pname)
            alpha=self.buildAlphabetIncludingPeerREC(pid)
            self.generateAlphaQueue(alpha,f,True)
            f.write(" (bq: BoundedQueue) is \n ")

            f.write(" select \n")
            for m in alpha:
                f.write("    if not(bisfull(bq)) then ")
                f.write(m+" ; "+pname)
                self.generateAlphaQueue(alpha,f,False)
                f.write(" (binsert("+m+",bq)) else stop end if\n")
                f.write("    [] \n")
                gaterec=m+"_REC"
                f.write("    if bishead("+m+",bq) then "+gaterec+" ; "+pname)
                self.generateAlphaQueue(alpha,f,False)
                f.write(" (bremove(bq)) else stop end if\n")
                f.write("    [] \n")

            f.write("    null \n ")
            f.write(" end select \n ")

            f.write("end process \n\n")

    # choreo is extended
    def extendedChoreoP(self):
        syncTransitions = filter (lambda trans: isinstance (trans, SyncTransition), self._T)
        return syncTransitions != []

    # checks if peer needs a monitor
    def needsMonitorP (self, pid):
        alpha = self.buildAlphabetMonitor(pid)
        return alpha != []

    # checks if peer need a synchronization process
    def needsSyncProcessP(self, pid):
        syncTransForPeer = filter (lambda trans:
                                   isinstance (trans, SyncTransition) and
                                   pid in map(lambda l: l.getSender().getName(), trans.getLabelSet()),
                                   self._T)
        return syncTransForPeer != []

   
    # generates a process who does the sync message after being "activated" (init_XZY message)
    # this is required, as LNT does not allow recursive calls in parallel composition
    # even if this is justied, as it is undecidable in general
    def generateSyncProcesses(self, p, f):
        pid = p.getName()
        if self.needsMonitorP(pid) and self.needsSyncProcessP(pid):
            print "peer ", pid, " requires a synchronization process"
            syncTransForPeer = filter (lambda trans:
                                       isinstance (trans, SyncTransition) and
                                       pid in map(lambda l: l.getSender().getName(), trans.getLabelSet()),
                                       self._T)

            for syncTransLabels in map(lambda snc: snc.getLabelSet(), syncTransForPeer):
                for syncLabel in filter(lambda l: l.getSender().getName() == pid, syncTransLabels):
                    processName = "syncP_" + pid + "_" + syncLabel.getMessage()
                    f.write ("\nprocess " + processName + " [")
                    msgName = pid + "_" + syncLabel.getReceiver().getName() + "_" + syncLabel.getMessage()
                    alpha = [msgName, "init_" + msgName]
                    self.dumpAlphabet(alpha, f, True)
                    f.write ("] is\nselect\n")
                    syncMessage =  pid + "_" + syncLabel.getReceiver().getName() + "_" + syncLabel.getMessage()
                    f.write ("init_" + syncMessage + "; " + syncMessage + "; " + processName + "[")
                    self.dumpAlphabet(alpha, f, False)
                    f.write("]\n[]\nnull\nend select") # or do nothing at all
                                                       # TODO is this correct for looping behavior?
                    f.write("\nend process\n")



    
    # generate peers that are monitored from parallel composition of
    # peers and their monitors, synchcronizing over the messages the peer sends
    # these are the messages the monitor will delay to repsect correct ordering
    def generateMonitoredPeers (self, p, f):

        if not self.needsMonitorP(p.getName()):
            return

        f.write ("\nprocess monitored_" + p.getName() + " [")
        alpha = self.buildAlphabetMonitored(p.getName(), False, True)
        self.dumpAlphabet(alpha, f, any)
        f.write ("] is\n")

        # hide sent "receives" from monitor
        f.write (" hide ")
        alpha = self.buildHideSetPeerMonitor(p.getName())
        self.dumpAlphabet(alpha, f, any)
        f.write (" in\n")

        # synchronize over the sent messages from peer
        # which are cached by the monitor
        f.write (" par ")
        alpha = self.buildSynchroSetPeerMonitor(p.getName())
        self.dumpAlphabet(alpha, f, False)
        f.write (" in\n")

        f.write ("  peer_" + p.getName() + " [")
        alpha = self.buildAlphabetIncludingPeerDir(p.getName())
        self.dumpAlphabet(alpha, f, False)
        f.write ("]")

        f.write ("\n  ||\n  monitor_" + p.getName() + " [")
        alpha = self.buildAlphabetMonitor(p.getName(), True, False)
        self.dumpAlphabet(alpha, f, False)
        f.write ("] ")

        f.write ("\n  end par")
        f.write ("\n end hide")
        f.write("\nend process\n")

    
    # Generate a monitor for a peer
    #
    def generateMonitor (self, peer, f):
        pid = peer.getName()
        if self.needsMonitorP(pid):
            initialState = self.getInitialState()
            f.write("\nprocess monitor_" + pid + "[")
            alpha = self.buildAlphabetMonitor(pid, False, False)
            self.dumpAlphabet(alpha, f, True)
            f.write ("] is\n")
            anzahl = 0
            if self.needsSyncProcessP(pid):
                syncTransForPeer = filter (lambda trans:
                                           isinstance (trans, SyncTransition) and
                                           pid in map(lambda l: l.getSender().getName(), trans.getLabelSet()),
                                           self._T)
                f.write ("hide ")
                alpha = self.buildAlphabetSyncProcesses(pid, True)
                self.dumpAlphabet(alpha, f, True)
                f.write (" in\npar ")

                i = 0
                numberSyncTrans = reduce(lambda x, y: x + y,
                                         map(lambda x: len(filter(lambda l: l.getSender().getName() == pid, x.getLabelSet())),
                                             syncTransForPeer))
                anzahl = numberSyncTrans
                for t in syncTransForPeer:
                    for syncLabel in t.getLabelSet():

                        if syncLabel.getSender().getName() == pid:

                            f.write ("init_" + pid + "_" + syncLabel.getReceiver().getName() + "_" + syncLabel.getMessage() + " in")
                            f.write ("\nsyncP_" + pid + "_" + syncLabel.getMessage() + "[")
                            msgName = pid + "_" + syncLabel.getReceiver().getName() + "_" + syncLabel.getMessage()
                            alpha = [msgName, "init_" + msgName]
                            self.dumpAlphabet(alpha, f, False)
                            f.write ("]\n")
                            i = i + 1
                            if i < numberSyncTrans:
                                f.write ("||\npar\n")

                f.write ("\n||\n")
            f.write ("monitor_" + pid + "_" + initialState.getName() + "[")
            alpha = self.buildAlphabetMonitor(pid)
            self.dumpAlphabet(alpha, f, False)
            f.write("]\n")
            for i in range(anzahl):
                f.write ("\nend par")
            if self.needsSyncProcessP(pid):
                f.write ("\nend hide")
            f.write ("\nend process\n")

            self.generateMonitorForState (peer, initialState, [], f)

    
    # generate monitor to enforce synchronizability
    # by using the information from the diagnostics
    def generateMonitorForState (self, peer, currentState, visitedStates, f):

        if currentState not in visitedStates:
            visitedStates.append(currentState)
            f.write ("\nprocess ")

            
            # computes the gates for the monitor process, these are obtained from the send messages in the peer
            # and which are split into receptions of these message by the peer and their emission to other
            # peer buffers

            f.write ("monitor_" + peer.getName() + "_" + currentState.getName() + " [")
            alpha = self.buildAlphabetMonitor(peer.getName())
            self.dumpAlphabet(alpha, f, any)
            f.write(" ] is\n")
            

            exitingTransitions = filter (lambda trans: trans.getSource().getName() == currentState.getName(),
                                         self.getAllTransitions())
            incomingSyncTransitions = filter(lambda trans: isinstance(trans, SyncTransition)
                                             and peer.getName() in map(lambda l: l.getReceiver().getName(), trans.getLabelSet()),
                                             self.getAllTransitions())


            i = 0
            f.write(" select\n")
            if len (exitingTransitions) == 0:
                f.write ("null\n")

             

            for trans in exitingTransitions:
                transLabel = trans.getLabel()
                targetState = trans.getTarget()
                sender = transLabel.getSender().getName()
                receiver = transLabel.getReceiver().getName()
                message = transLabel.getMessage()

                # case 1) peer sends message -> emit local reception and relay
                if not isinstance(trans, SyncTransition) and sender == peer.getName():
                    f.write(sender + "_" + receiver + "_" + message + "_DLY;\n")
                    f.write(sender + "_" + receiver + "_" + message + ";\n (*XXX*)")
                    f.write ("monitor_" + peer.getName() + "_" + trans.getTarget().getName () + "[")
                    self.dumpAlphabet(alpha, f, False)
                    f.write ("]")


                # case 2) peer is synchronizing -> start synchronization Process
                elif isinstance (trans, SyncTransition) and peer.getName() in map(lambda l: l.getSender().getName(), trans.getLabelSet()):

                   

                    trans.generateSyncs(f, True, peer.getName())
                    f.write ("monitor_" + peer.getName() + "_" + trans.getTarget().getName () + "[")
                    self.dumpAlphabet(alpha, f, False)
                    f.write ("]")


                # Case 3) peer is to be synchronized
                elif isinstance (trans, SyncTransition) and peer.getName() in map(lambda label: label.getReceiver().getName(), trans.getLabelSet()):

                    exitingFromTargetState = filter(lambda t: t.getSource().getName() == targetState.getName()
                                                    and t.getLabel().getSender().getName() == peer.getName(),
                                                    self.getAllTransitions())

                    f.write("select\n")
                    i2 = len(exitingFromTargetState)

                    for nextStateTrans in exitingFromTargetState:

                        nextLabel = nextStateTrans.getLabel()
                        nextReceiver = nextLabel.getReceiver().getName()
                        nextMessage = nextLabel.getMessage()


                        if nextLabel.getSender().getName() == peer.getName():
                            f.write(peer.getName() + "_" + nextReceiver + "_" + nextMessage + "_DLY; (*YYY*)\n")
                            resultList = filter(lambda label: label.getReceiver().getName() == peer.getName(), trans.getLabelSet())
                            if len(resultList) > 1:
                                f.write("  par\n")
                            for syncNr in range(0,len(resultList)):
                                f.write(resultList[syncNr].getSender().getName()
                                        + "_" + peer.getName() + "_" + resultList[syncNr].getMessage() + "\n")
                                if syncNr + 1 < len(resultList):
                                    f.write("\n||\n")
                            if len(resultList) > 1:
                                f.write("  end par")
                            f.write(";\n")
                            f.write(peer.getName() + "_" + nextReceiver + "_" + nextMessage + ";\n")

                        else:
                            f.write("i;\n")
                        f.write ("monitor_" + peer.getName() + "_" + nextStateTrans.getTarget().getName () + "[")
                        self.dumpAlphabet(alpha, f, False)
                        f.write ("]")

                        if i2 > 1:
                            f.write("\n[] (*BUBU*)\n")
                        i2 = i2 - 1

                    f.write("end select\n")

                # case 4) peer is not participating
                else:
                    # subcases a) there is an outgoing synchronized transition for peer in a predecessor
                    predecessorTrans = filter(lambda t: isinstance(t, SyncTransition)
                                              and t.getSource() == trans.getSource()
                                              # multiple synctrans
                                              and peer.getName() in map(lambda label: label.getReceiver().getName(), t.getLabelSet()),
                                              self.getAllTransitions())

                    if len(predecessorTrans) == 0:
                        f.write("i;\n")
                        f.write ("monitor_" + peer.getName() + "_" + trans.getTarget().getName () + "[")
                        self.dumpAlphabet(alpha, f, False)
                        f.write ("]")
                    else:
                        i = i + 1

                i = i + 1
                if i < len (exitingTransitions):
                    f.write ("\n[] (*BABA*)\n")

            f.write(" end select\n")
            f.write ("end process\n\n")

            # recursive call with updated "visitedStates" information
            neighbours = map (lambda trans: trans.getTarget(), exitingTransitions)
            for neighbour in neighbours:
                self.generateMonitorForState (peer, neighbour, visitedStates, f)
        return

    ##
    # Generates an LNT process for a peer queue
    def generatePeerQueue(self,pid,alpha,f, withMonitors = False):
        f.write("process ")
        pname="peer_queue_"+pid
        f.write(pname)
        alpha=self.buildAlphabetIncludingPeer_PQbis(pid, False)
        alphaqueue=self.buildAlphabetIncludingPeerREC(pid)
        alphapeer=self.buildAlphabetIncludingPeer_PQ(pid, False)
        f.write(" [")
        self.dumpAlphabet(alpha,f,True)
        f.write("] is \n")
        f.write("  par ")
        if alphaqueue!=[]:
           self.dumpAlphabetWithREC(alphaqueue,f,False)
           f.write(" in \n")
        if withMonitors and self.needsMonitorP(pid):
            f.write("    monitored_"+pid+" [")
            alpha = self.buildAlphabetMonitored(pid, False, True)
        else:
            f.write ("    peer_" + pid + " [")
            alpha = self.buildAlphabetIncludingPeer_PQ(pid)
        self.dumpAlphabet(alpha,f, False)
        f.write("] \n")
        f.write("    || \n")
        f.write("    queue_"+pid)
        self.generateAlphaQueue(alphaqueue,f,False)
        f.write("(bqueue(nil,1)) \n")
        f.write("  end par \n")
        f.write("end process \n\n")

    # compute parallel composition of (monitor || peer) || buffer?
    #  - the hide parameter seems to be rather obsolete (creates the compoCS LTS)
    #  - parallelSVLSyntax triggers smart reduction (on SVL level)
    #    compatible parallel composition syntax generation
    def generateComposition(self,alpha,peers,f,hide,name, synchronousComposition = False, parallelSVLSyntax = False):
        if not parallelSVLSyntax:
            f.write("process ")
            f.write(name)
            f.write(" [")
            self.dumpAlphabet(alpha,f,True)
            if not(hide):
                f.write(",")
                # no REC for the sync messages!
                alpha = self.buildAlphabet(False)
                self.dumpAlphabetWithREC(alpha,f,True)
            f.write("] is \n")
        i=0

        alphaSync = self.getSyncLabels()

        if parallelSVLSyntax and len(alphaSync) > 0:
            f.write("(total hide ")
            self.dumpAlphabet(alphaSync,f,False)
            f.write (" in ")

        max=len(peers)
        for p in peers:
            pid=p.getName()
            if (i+1)<max:
                f.write("par ")
                # synchro set computation
                synchro=self.computeSynchro(pid,peers[i+1:])
                if synchro!=[]:
                    self.dumpAlphabet(synchro,f,False)
                    f.write(" in")
                elif parallelSVLSyntax:
                    f.write(" in")
                f.write("\n")
            if hide:
                if synchronousComposition:
                    alphaqueue = self.buildAlphabetIncludingPeer (pid)
                else:
                    alphaqueue=self.buildAlphabetIncludingPeerREC(pid)
                if alphaqueue!=[] and not synchronousComposition:
                    if parallelSVLSyntax:
                        f.write ("(total hide ")
                        self.dumpAlphabetWithREC(alphaqueue, f, False)
                    else:
                        f.write("hide ")
                        self.dumpAlphabetWithREC(alphaqueue,f,True)
                    f.write(" in\n")
            alpha=self.buildAlphabetIncludingPeer_PQbis(pid, False)
            if not synchronousComposition:
                pname=" peer_queue_"+pid
            else:
                alpha = self.buildAlphabetIncludingPeer (pid, False)
                if self.needsMonitorP(pid) and self.extendedChoreoP():
                    pname = "monitored_" + pid
                else:
                    pname = "peer_" + pid

            f.write(pname)
            f.write(" [")
            self.dumpAlphabet(alpha,f,False)
            f.write("]\n")
            if hide and not synchronousComposition:
                if alphaqueue!=[]:
                    if parallelSVLSyntax:
                        f.write (")\n")
                    else:
                        f.write("end hide\n")
            i=i+1
            if (i<max):
                f.write("||\n")
        i=1
        while (i<max):
           f.write("end par\n")
           i=i+1
        if not parallelSVLSyntax:
            f.write("end process\n\n")
        else:
            if parallelSVLSyntax and len(alphaSync) > 0:
                f.write(")")
            f.write (";\n\n")


    ##
    # Computes a synchronisation set given a peer and a list of peers
    # extended 5.12. Matthias:
    #   also respects the synchronization messages from the monitors
    def computeSynchro(self,pid,peers):
        alpha=self.buildAlphabetIncludingPeer(pid)
        alphas=[]

        # computes those transitions where pid is sender,
        # one peer in the set peers is receiver or vice versa
        # these also have to added as synchronization labels!
   
        emitSyncTrans = filter(lambda trans: isinstance(trans, SyncTransition) and
                               pid in map(lambda l: l.getSender().getName(), trans.getLabelSet()),
                               self._T)

        # keep only those labels, where pid is sender and receiver is in "peers" set
        emitSyncLabels = []
        for t in emitSyncTrans:
            map(lambda l: emitSyncLabels.append(l),
                filter(lambda l: l.getSender().getName() == pid and l.getReceiver().getName() in map(lambda peer: peer.getName(), peers),
                       t.getLabelSet()))

        incomingSyncTrans = filter(lambda trans: isinstance(trans, SyncTransition) and
                                   pid in map(lambda l: l.getReceiver().getName(), trans.getLabelSet()) and
                                   trans.getLabel().getSender().getName() in map(lambda peer: peer.getName(), peers),
                                   self._T)

        # keep only those labels where sender in "peers" set and pid is receiver
        incSyncLabels = []
        for t in incomingSyncTrans:
            map(lambda l: incSyncLabels.append(l),
                filter(lambda l: l.getReceiver().getName() == pid and
                       l.getSender() in peers, t.getLabelSet()))

        labelSet = emitSyncLabels  + incSyncLabels


        for k in peers:
            ak=self.buildAlphabetIncludingPeer(k.getName())
            alphas=self.union(alphas,ak)

        return self.union (self.intersection(alpha,alphas),
                           map (lambda l:
                                l.getSender().getName() + "_" +
                                l.getReceiver().getName() + "_" +
                                l.getMessage(), labelSet))


    ##
    # Computes the union of 2 lists
    def union(self,l1,l2):
        l=[]
        for e in l1:
            if not(e in l2):
               l.append(e)
        l.extend(l2)
        return l

    ##
    # Computes the intersection of 2 lists
    def intersection(self,l1,l2):
        l=[]
        for e in l1:
            if e in l2:
               l.append(e)
        return l


    # return list of all synchronization labels (for hiding in SVL)
    def getSyncLabels(self):
        strans = filter(lambda trans: isinstance(trans, SyncTransition), self.getAllTransitions())

        syncLabels = []
        for trans in strans:
            for l in trans.getLabelSet():
                syncLabels.append(l.getSender().getName() + "_" + l.getReceiver().getName() + "_" + l.getMessage())

        return syncLabels


    # Generates an SVL file
    def generateSVL(self, smartComposition = False, generateDebugBCG = False):
        name=self._name
        filename=name+".svl"
        f=open(filename, 'w')
        f.write("% CAESAR_OPEN_OPTIONS=\"-silent -warning\"\n% CAESAR_OPTIONS=\"-more cat\"% CADP_TIME=\"/usr/bin/time\"\n\n")
        f.write ("% DEFAULT_PROCESS_FILE=" + name + ".lnt\n\n")
        # CP generation (LTS)
        f.write("\""+name+"_cp.bcg\" = tau*.a reduction of ")

        alphaSync = self.getSyncLabels()

        if len(alphaSync) > 0:
            f.write("(total hide ")
            self.dumpAlphabet(alphaSync,f,False)
            f.write (" in ")

        f.write(" \"MAIN [")
        alpha=self.buildAlphabet(False)
        self.dumpAlphabet(alpha,f,False)
        f.write("]\"")
        if len(alphaSync) > 0:
            f.write(")")
        f.write(";\n\n")

        if not smartComposition:
            # then we use compositional verification
            # faster, but larger intermediate state-spaces
            f.write("\""+name+"_compo.bcg\" = root leaf branching reduction of\n")
            alpha = self.buildAlphabet(False)
            peers=self.getPeers()
            self.generateComposition(alpha, peers, f, True, "compo", False, True)
        else:
            f.write("\""+name+"_compo.bcg\" = smart branching reduction of\n")
            alpha = self.buildAlphabet(False)
            peers=self.getPeers()
            self.generateComposition(alpha, peers, f, True, "compo", False, True)

        f.write("\""+name+"_compo_min.bcg\"= weak trace reduction of safety reduction of tau*.a reduction of branching reduction of \""+name+"_compo.bcg\" ;\n\n")

        # synchronous composition
        if not smartComposition:
            f.write("\""+name+"_compo_sync.bcg\" = root leaf branching reduction of\n")
            alpha = self.buildAlphabet(False)
            peers=self.getPeers()
            self.generateComposition(alpha, peers, f, True, "compo_sync", True, True)
        else:
            f.write("\""+name+"_compo_sync.bcg\" = smart branching reduction of\n")
            alpha = self.buildAlphabet(False)
            peers=self.getPeers()
            self.generateComposition(alpha, peers, f, True, "compo_sync", True, True)

        f.write("\""+name+"_compo_sync_min.bcg\"= weak trace reduction of safety reduction of tau*.a reduction of branching reduction of \""+name+"_compo_sync.bcg\" ;\n\n")
       

        if generateDebugBCG:
            # peer generation
            peers=self.getPeers()
            for p in peers:
                pid=p.getName()
                incalphapid_dir=self.buildAlphabetIncludingPeerDir(pid)
                f.write("\""+name+"_peer_" + pid + ".bcg\" = ")
                f.write("safety reduction of tau*.a reduction of branching reduction of \"peer_" + pid +" [")
                self.dumpAlphabet(incalphapid_dir,f,False)
                f.write("]\";\n\n")

                if  self.needsMonitorP(pid):
                    f.write("\""+name+"_monitor_" + pid + ".bcg\" = generation of \"monitor_" + pid + " [")
                    monitorAlpha = self.buildAlphabetMonitor(pid, False, False)
                    self.dumpAlphabet(monitorAlpha, f, False)
                    f.write("]\";\n\n")

                    f.write("\""+name+"_monitored_" + pid + ".bcg\" = safety reduction of tau*.a reduction of branching reduction of \"monitored_" + pid + " [")
                    monitoredAlpha = self.buildAlphabetMonitored(pid, False, False)
                    self.dumpAlphabet(monitoredAlpha, f, False)
                    f.write("]\";\n\n")

        f.close()

        filename=name+"-synchronizability.svl"
        f=open(filename, 'w')
        f.write("\"synchronizability.bcg\" =  strong comparison using bfs with bisimulator \""+name+"_compo_sync_min.bcg\" == \""+name+"_compo_min.bcg\"");
        f.close()

        filename=name+"-realizability.svl"
        f=open(filename, 'w')
        f.write("\"realizability.bcg\" = strong comparison using bfs with bisimulator  \""+name+"_cp.bcg\" == \""+name+"_compo_min.bcg\";")
        f.close()

    # Generates SVL code to compute the canonical schedule
    def generateCanonicalSchedule(self,peers,f):
        f.write("\"canonical_schedule.bcg\"=total prio\n")
        lacr=[]
        laem=[]
        for p in peers:
            pid=p.getName()
            acr=self.buildAlphabetChoiceRec(pid)
            aem=self.buildAlphabetEm(pid)
            if acr!=[]:
               lacr.append(acr)
            if aem!=[]:
               laem.append(aem)
        i=0
        max=len(lacr)
        for l in lacr:
            self.dumpAlphabet(l,f,False)
            i=i+1
            if (i<max):
               f.write(">")
        if laem!=[]:
           f.write(">")
        i=0
        max=len(laem)
        for l in laem:
            self.dumpAlphabet(l,f,False)
            i=i+1
            if (i<max):
               f.write(">")
        f.write(" in \"compoCS_min.bcg\" ;\n\n")


class Checker:

    # remove all files generated by the svl execution
    def cleanUp(self, cp):
        name = cp.getName()
        print "removing old bcg files"
        process = Popen (["svl","-clean",name], shell = False, stdout=PIPE)
        output = process.communicate()
        process = Popen (["rm",name+"_compo.bcg",name+"_compo_sync.bcg",name+"_cp.bcg"], stderr=PIPE, stdout=PIPE)
        process.communicate()
        print "removing old diagnostics"
        process = Popen (["rm","synchronizability.bcg","realizability.bcg"], stderr=PIPE, stdout=PIPE)
        process.communicate()

    def generateLTS(self, cp, debugOutput = False):
        name = cp.getName()
        print "run LTS generation for choreo"
        process = Popen (["svl",name], shell = False, stdin=PIPE, stdout=PIPE, stderr=PIPE)
        process.communicate()
        if debugOutput:
            print output[0]
            print output[1]
        if process.returncode != 0:
            return False
        else:
            return True

    def isSynchronizableP(self, cp, debugOutput = False):
        print "run synchronizability check"
        name = cp.getName()
        process = Popen (["svl",name+"-synchronizability"], shell = False, stdout=PIPE)
        output = process.communicate()
        if debugOutput:
            if os.path.isfile ("synchronizability.bcg"):
                process = Popen (["bcg_info","-labels","synchronizability.bcg"], shell = False, stdout=PIPE)
                print process.communicate()[0]
        return not (os.path.isfile ("synchronizability.bcg"))

    def isRealizableP(self, cp, debugOutput = False):
        print "run realizability check"
        name = cp.getName()
        process = Popen (["svl",name+"-realizability"], shell = False, stdout=PIPE)
        output = process.communicate()
        if debugOutput:
            if os.path.isfile ("realizability.bcg"):
                process = Popen (["bcg_info","-labels","realizability.bcg"], shell = False, stdout=PIPE)
                print process.communicate()[0]
        return not (os.path.isfile ("realizability.bcg"))

    def readCounterEx(self, cp, diagFile = "realizability.bcg"):
        name=cp.getName()
        process = Popen (["bcg_info","-labels", diagFile], shell = False, stdout=PIPE)
        output = process.communicate()[0]
        lines = output.split('\n')
        counterList = filter (lambda line: line.find('Present in '+name+'_compo_min.bcg: ') != -1, lines)
        if len (counterList) == 0:
            print "Error, did not find useable counterexample in choreo!"
            return
        counterExFull = counterList[0]
        counterEx = counterExFull[len ('Present in '+name+'_compo_min.bcg: '):(len (counterExFull))]
        return counterEx


    def extendChoreo(self, cp, sender, receiver, number, msg, askIfMultiple = False):
        """ extends a choreography given a transition that was a diagnostics in the
            synchronizability check

        cp -- the choreography to extend
        sender -- the sending peer
        receiver -- the receiving peer
        msg -- the message of the transition in the diagnostic
        """
        global numTran
        print "extending choreo because of ", sender, receiver, msg, " transition"
        offendingLabel = cp.createLabel (sender, receiver, msg)
        transitionsToFix = cp.findOffendingTransitions (offendingLabel)

	numTran=len(transitionsToFix)
        if len(transitionsToFix) > 1:
            print "multiple possible transitions found\nTODO: read whole counterex and use breadth first search"
            if not askIfMultiple:
                return False
            i = 0
            for t in transitionsToFix:
                print i,
                t.printTransition()
                print "\n"
                i = i + 1
            try:
                transitionsToFix = [transitionsToFix[number]]
            except ValueError:
                print "Not a number"
                return False

        print "transitions needed to fix ", map (lambda trans: trans.printTransition(), transitionsToFix)
        synchroState = transitionsToFix[0].getSource()
        print "synchro State is ", synchroState.printState()
        fixTrans = transitionsToFix[0]
        return cp.insertSynchroMessage(fixTrans)


    def checkChoreo(self, cp, smartReduction = True, debugInfoMonitors = False):
    
        choreoName = cp.getName()
        synchronizabilityLoop = True
        if not cp.checkAllConditions():
            print "This choreography is faulty"
        else:
            print "This choreography is not a faulty one and thus repairable"
            print "======\n"
            number=0
            while True:
                startTime = time()
                print "checking this choreography"
                cp.printCP()

                print "generate LNT file"
                cp.cp2lnt (True)
                if not smartReduction:
                    print "generate SVL with compositional verification"
                else:
                    print "generate SVL file with smart reduction"
                cp.generateSVL(smartReduction, debugInfoMonitors)

                self.cleanUp(cp)
                if not self.generateLTS(cp, False):
                    print "error in LTS generation, return svl manually to see the errors\n"
                    print "===\n"
                    break


                if synchronizabilityLoop:
                    if self.isSynchronizableP(cp, True):
                        print "this choreography is synchronizable in this form"
                        print "===\n"
                        synchronizabilityLoop = False
                    else:
                        print "this choreography is not synchronizable and not realizable in this form"
                        print "===\n"
                        self.isRealizableP(cp, True)
                        counterex = self.readCounterEx(cp)
                         
                if not synchronizabilityLoop:
                    if self.isRealizableP(cp, True):
                        print "the choreography is realizable in this form"
                        print "===\n"
                        elapsed = time() - startTime
                        print "iteration time: ", elapsed, "s"
                        break
                    else:
                        print "the choreography is not realizable in this form"
                        print "===\n"
                        counterex = self.readCounterEx(cp, "realizability.bcg")
                if counterex == "exit":
                    print "found exit in bcg, unclear what to do\n===\n"
                    break

                elapsed = time() - startTime
                print "iteration time: ", elapsed, "s"

		
                [sender, receiver, msg] = counterex.lower().split('_')
		global numTran
                numTran=0
                if not self.extendChoreo(cp, sender, receiver, number, msg, True):
                     print "===\n"
                     break
                if number==numTran-1:
                     number=0
                else:
                     number=number+1





if __name__ == '__main__':

	import sys
	import os
	from subprocess import Popen, PIPE
        SUFFIX = ".xml"
	

	if len(sys.argv) == 2:
		infile = sys.argv[1]
		# check if CIF (xml suffix)
        	elements = infile.split(SUFFIX)
       	 	if (len(elements)>=2 and elements[-1]==''):
            		filename = infile[:-(len(SUFFIX))]
                        
            		basefilename = os.path.basename(filename)
            		dirfilename = os.path.dirname(filename)
        	else:
            		print "%s: wrong resource type (should be .xml)" % infile
            		sys.exit(1)
		 
		s3=basefilename+"_bpmnlts_min.bcg"
                s4=basefilename+"_bpmnlts_min.aut"
                #transform from bcg to aut
                p3=Popen(['bcg_io', s3, s4], stdout=PIPE)
	        p3.wait()
                #transform from aut to python format
		p4=Popen(['python', 'aut2cp.py', s4, basefilename], stdout=PIPE)
		p4.wait()
		import cpExa
		ex=cpExa.ExternalExamples()
		checker = Checker()
                
                
		liste = [
           
			ex.cp_example()
          
             ]
                
		map (lambda ex: checker.checkChoreo(ex, True, True), liste)
                
     
